﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ATM_Management_System_Using_Csharp
{
    class Connection
    {
       public string db = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\hp\documents\visual studio 2010\Projects\ATM Management System Using Csharp\ATM Management System Using Csharp\ATM_M_S.mdf;Integrated Security=True;User Instance=True";
    }
}
